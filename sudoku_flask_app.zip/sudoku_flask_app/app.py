from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

class Sudoku:
    def __init__(self, size=9, difficulty='easy'):
        self.size = size
        self.grid = [[0 for _ in range(self.size)] for _ in range(self.size)]
        self.difficulty = difficulty

    def is_valid(self, num, pos):
        for i in range(self.size):
            if self.grid[pos[0]][i] == num and pos[1] != i:
                return False
        for i in range(self.size):
            if self.grid[i][pos[1]] == num and pos[0] != i:
                return False
        
        box_size = int(self.size ** 0.5)
        box_x = pos[1] // box_size
        box_y = pos[0] // box_size
        for i in range(box_y * box_size, box_y * box_size + box_size):
            for j in range(box_x * box_size, box_x * box_size + box_size):
                if self.grid[i][j] == num and (i, j) != pos:
                    return False
        return True

    def solve(self):
        empty = self.find_empty()
        if not empty:
            return True
        row, col = empty
        for num in range(1, self.size + 1):
            if self.is_valid(num, (row, col)):
                self.grid[row][col] = num
                if self.solve():
                    return True
                self.grid[row][col] = 0
        return False

    def find_empty(self):
        for i in range(self.size):
            for j in range(self.size):
                if self.grid[i][j] == 0:
                    return (i, j)
        return None

    def generate_puzzle(self):
        self.solve()
        self.remove_numbers()
        return self.grid

    def remove_numbers(self):
        remove_count = int(self.size * self.size * 0.5)
        if self.difficulty == 'medium':
            remove_count += int(self.size * self.size * 0.1)
        elif self.difficulty == 'hard':
            remove_count += int(self.size * self.size * 0.2)

        while remove_count > 0:
            row = random.randint(0, self.size - 1)
            col = random.randint(0, self.size - 1)
            if self.grid[row][col] != 0:
                self.grid[row][col] = 0
                remove_count -= 1

    def validate_solution(self, user_grid):
        for i in range(self.size):
            for j in range(self.size):
                num = user_grid[i][j]
                if not self.is_valid(num, (i, j)):
                    return False
        return True


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate_puzzle():
    size = int(request.form.get('size', 9))
    difficulty = request.form.get('difficulty', 'easy')
    sudoku = Sudoku(size, difficulty)
    grid = sudoku.generate_puzzle()
    return jsonify(grid)


@app.route('/solve', methods=['POST'])
def solve_puzzle():
    grid = request.json['grid']
    size = len(grid)
    sudoku = Sudoku(size)
    sudoku.grid = grid
    sudoku.solve()
    return jsonify(sudoku.grid)


@app.route('/submit', methods=['POST'])
def submit_solution():
    grid = request.json['grid']
    size = len(grid)
    sudoku = Sudoku(size)
    is_correct = sudoku.validate_solution(grid)
    return jsonify({'result': is_correct})


if __name__ == '__main__':
    app.run(debug=True)
