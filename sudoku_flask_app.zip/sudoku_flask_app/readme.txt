Step1: Open the sudoku flask app folder.
Step2: Top path type cmd.
Step3: Paste and run 'pm2 start app.py --interpreter=python'
Step4: Open new cmd
Step5: run 'cd downloads'
Step6: run 'ngrok http 5000'
